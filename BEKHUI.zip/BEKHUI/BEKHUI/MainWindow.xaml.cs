﻿using BEKHUI.Model;
using BEKHUI.Service;
using System.ComponentModel;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace BEKHUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ISongService service;
        private ICollectionView songView;

        public MainWindow()
        {
            InitializeComponent();

            service = new SongService();
            songView = CollectionViewSource.GetDefaultView(service.Songs);
            SongGrid.ItemsSource = songView;
        }

        public void Action_Click(object sender, RoutedEventArgs e) 
        {
            var tag = (sender as FrameworkElement).Tag.ToString();
            var selected = SongGrid.SelectedItem as Song;
            if (tag == "add")
            {
                var win = new EditWindow();
                if (win.ShowDialog() == true)
                {
                    service.Add(win.NewSong);
                }
            }
            else if (tag == "delete")
            {
                service.Delete(selected);
            }
            else if (tag == "fav")
            {
                service.ToggleFavorite(selected);
            }
            else if (tag == "edit") 
            {
                var win = new EditWindow(selected);
                if (win.ShowDialog() == true) 
                {
                    service.SaveToFile();
                }

            }


        }
        private void SearchChanged(object sender, RoutedEventArgs e) 
        {
            string text = Searchbox.Text.ToLower();
            bool onlyFav = FavCheck.IsChecked == true;
            songView.Filter = obj =>
            {
                if (obj is Song song)
                {
                    bool matchesSearch = song.Title.ToLower().Contains(text) || song.Artist.ToLower().Contains(text) || song.Genre.ToLower().Contains(text);
                    bool matchesFav = !onlyFav || song.IsFavorite;
                    return matchesSearch && matchesFav;
                }
                return false;
            };
        }

        private void SortChanged (object sender, System.Windows.Controls.SelectionChangedEventArgs e) 
        {
            if (SortBox.SelectedItem == null) return;
            string sortBy = (SortBox.SelectedItem as System.Windows.Controls.ComboBoxItem).Content.ToString();
            songView.SortDescriptions.Clear();
            songView.SortDescriptions.Add(new SortDescription(sortBy, ListSortDirection.Ascending));
        }
    }
}