﻿using BEKHUI.Model;
using BEKHUI.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace BEKHUI
{
    /// <summary>
    /// Interaction logic for EditWindow.xaml
    /// </summary>
    public partial class EditWindow : Window
    {
        public Song NewSong { get; set; }
        public EditWindow()
        {
            InitializeComponent();
        }
        public EditWindow(Song song)
        {
            InitializeComponent();

            TitleBox.Text = song.Title;
            ArtistBox.Text=song.Artist;
            GenreBox.Text = song.Genre;
            DurationBox.Text = song.Duration.ToString();

            NewSong = song;
        }

        private void Save_Click(object sender, RoutedEventArgs e) 
        {
            if (NewSong == null)
                NewSong = new Song();

            NewSong.Title = TitleBox.Text;
            NewSong.Artist = ArtistBox.Text;
            NewSong.Genre = GenreBox.Text;
            NewSong.Duration = int.TryParse(DurationBox.Text, out int d) ? d : 0;

            DialogResult = true;
        }
    }
}
