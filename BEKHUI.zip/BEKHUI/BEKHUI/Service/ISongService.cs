﻿using BEKHUI.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEKHUI.Service
{
    public interface ISongService
    {
        ObservableCollection<Song> Songs { get; }
        void Add(Song song);
        void Delete(Song song);
        void ToggleFavorite(Song song);
        void SaveToFile();
    }
}
