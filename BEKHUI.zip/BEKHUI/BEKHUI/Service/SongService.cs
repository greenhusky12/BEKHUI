﻿using BEKHUI.Model;
using CommunityToolkit.Mvvm.ComponentModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace BEKHUI.Service
{
    public partial class SongService :ObservableObject, ISongService
    {
        [ObservableProperty]
        private ObservableCollection<Song> songs = new ObservableCollection<Song>();

        public SongService()
        {
            LoadFromFile();
            if(Songs.Count == 0)
            SeedData();
        }

        private void SeedData() 
        {
            Songs.Add(new Song { Title = "Shape of you", Artist = "Ed Sheeran", Genre = "Pop", Duration = 240 });
            Songs.Add(new Song { Title = "Till I Collapse", Artist = "Eminem", Genre = "Rap", Duration = 320 });
            //Songs.Add(new Song { Title = " ", Artist = " ", Genre = "", Duration =  });

            Songs[0].IsFavorite = true; 
        }
        public void Add(Song song) 
        {
            Songs.Add(song);
            SaveToFile();
            
        }

        public void Delete(Song song) 
        {
            if (song != null) Songs.Remove(song);
            SaveToFile();
        }

        public void ToggleFavorite(Song song) 
        {
            if (song != null) 
            {
                song.IsFavorite = !song.IsFavorite;
            }
            SaveToFile();
            
        }

        public void SaveToFile() 
        {
            var options = new JsonSerializerOptions
            {
                WriteIndented = true
            };
            var json = JsonSerializer.Serialize(Songs, options);
            File.WriteAllText("songs.json", json);

        }

        public void LoadFromFile() 
        {
            if (File.Exists("songs.json")) 
            {
                var json = File.ReadAllText("songs.json");
                var loaded = JsonSerializer.Deserialize<ObservableCollection<Song>>(json);
                if (loaded != null) Songs = loaded;
            }
        }

        public ObservableCollection<Song> GetFavorites() 
        {
            return new ObservableCollection<Song>(Songs.Where(s => s.IsFavorite));
        }
    }
}
