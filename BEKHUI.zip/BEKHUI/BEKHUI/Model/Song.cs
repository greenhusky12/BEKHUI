﻿using CommunityToolkit.Mvvm.ComponentModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BEKHUI.Model
{
    public partial class Song : ObservableObject
    {
        [ObservableProperty]
        private string title;
        [ObservableProperty]
        private string artist;
        [ObservableProperty]
        private string genre;
        [ObservableProperty]
        private int duration;
        [ObservableProperty]
        private bool isFavorite;

    }
}
